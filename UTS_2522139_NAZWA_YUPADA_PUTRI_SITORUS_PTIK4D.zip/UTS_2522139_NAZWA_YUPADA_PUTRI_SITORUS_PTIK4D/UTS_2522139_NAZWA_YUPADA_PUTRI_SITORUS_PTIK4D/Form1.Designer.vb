﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.JPI2 = New System.Windows.Forms.TextBox()
        Me.JPI3 = New System.Windows.Forms.TextBox()
        Me.JPI4 = New System.Windows.Forms.TextBox()
        Me.JPI1 = New System.Windows.Forms.TextBox()
        Me.HPI2 = New System.Windows.Forms.TextBox()
        Me.HPI4 = New System.Windows.Forms.TextBox()
        Me.HPI3 = New System.Windows.Forms.TextBox()
        Me.HPI1 = New System.Windows.Forms.TextBox()
        Me.PI2 = New System.Windows.Forms.CheckBox()
        Me.PI3 = New System.Windows.Forms.CheckBox()
        Me.PI4 = New System.Windows.Forms.CheckBox()
        Me.PI1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.HPA3 = New System.Windows.Forms.TextBox()
        Me.HPA2 = New System.Windows.Forms.TextBox()
        Me.HPA1 = New System.Windows.Forms.TextBox()
        Me.JPA3 = New System.Windows.Forms.TextBox()
        Me.PA3 = New System.Windows.Forms.CheckBox()
        Me.JPA2 = New System.Windows.Forms.TextBox()
        Me.JPA1 = New System.Windows.Forms.TextBox()
        Me.PA1 = New System.Windows.Forms.CheckBox()
        Me.PA2 = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.HM3 = New System.Windows.Forms.TextBox()
        Me.HM2 = New System.Windows.Forms.TextBox()
        Me.HM1 = New System.Windows.Forms.TextBox()
        Me.M3 = New System.Windows.Forms.CheckBox()
        Me.JM3 = New System.Windows.Forms.TextBox()
        Me.JM2 = New System.Windows.Forms.TextBox()
        Me.JM1 = New System.Windows.Forms.TextBox()
        Me.M2 = New System.Windows.Forms.CheckBox()
        Me.M1 = New System.Windows.Forms.CheckBox()
        Me.BtnHitung = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextTotal = New System.Windows.Forms.TextBox()
        Me.TextKembali = New System.Windows.Forms.TextBox()
        Me.TextBayar = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(44, 28)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(172, 142)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bernard MT Condensed", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(232, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(296, 38)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Free Ongkir All Variant"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MV Boli", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(223, 102)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(311, 29)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Untuk Wilayah Bukittinggi"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(57, 203)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(87, 69)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 4
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(658, 203)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(87, 69)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 5
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(57, 463)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(87, 69)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 6
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(57, 388)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(87, 69)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 7
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(57, 278)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(87, 69)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 8
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(658, 278)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(87, 69)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 9
        Me.PictureBox7.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.JPI2)
        Me.GroupBox1.Controls.Add(Me.JPI3)
        Me.GroupBox1.Controls.Add(Me.JPI4)
        Me.GroupBox1.Controls.Add(Me.JPI1)
        Me.GroupBox1.Controls.Add(Me.HPI2)
        Me.GroupBox1.Controls.Add(Me.HPI4)
        Me.GroupBox1.Controls.Add(Me.HPI3)
        Me.GroupBox1.Controls.Add(Me.HPI1)
        Me.GroupBox1.Controls.Add(Me.PI2)
        Me.GroupBox1.Controls.Add(Me.PI3)
        Me.GroupBox1.Controls.Add(Me.PI4)
        Me.GroupBox1.Controls.Add(Me.PI1)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(160, 193)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(476, 164)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "PIzza"
        '
        'JPI2
        '
        Me.JPI2.Location = New System.Drawing.Point(399, 62)
        Me.JPI2.Name = "JPI2"
        Me.JPI2.Size = New System.Drawing.Size(71, 26)
        Me.JPI2.TabIndex = 19
        Me.JPI2.Text = "0"
        Me.JPI2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'JPI3
        '
        Me.JPI3.Location = New System.Drawing.Point(399, 94)
        Me.JPI3.Name = "JPI3"
        Me.JPI3.Size = New System.Drawing.Size(71, 26)
        Me.JPI3.TabIndex = 18
        Me.JPI3.Text = "0"
        Me.JPI3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'JPI4
        '
        Me.JPI4.Location = New System.Drawing.Point(399, 126)
        Me.JPI4.Name = "JPI4"
        Me.JPI4.Size = New System.Drawing.Size(71, 26)
        Me.JPI4.TabIndex = 17
        Me.JPI4.Text = "0"
        Me.JPI4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'JPI1
        '
        Me.JPI1.Location = New System.Drawing.Point(399, 23)
        Me.JPI1.Name = "JPI1"
        Me.JPI1.Size = New System.Drawing.Size(71, 26)
        Me.JPI1.TabIndex = 10
        Me.JPI1.Text = "0"
        Me.JPI1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'HPI2
        '
        Me.HPI2.Location = New System.Drawing.Point(243, 62)
        Me.HPI2.Name = "HPI2"
        Me.HPI2.Size = New System.Drawing.Size(131, 26)
        Me.HPI2.TabIndex = 7
        Me.HPI2.Text = "39500"
        '
        'HPI4
        '
        Me.HPI4.Location = New System.Drawing.Point(243, 128)
        Me.HPI4.Name = "HPI4"
        Me.HPI4.Size = New System.Drawing.Size(131, 26)
        Me.HPI4.TabIndex = 6
        Me.HPI4.Text = "40500"
        '
        'HPI3
        '
        Me.HPI3.Location = New System.Drawing.Point(243, 96)
        Me.HPI3.Name = "HPI3"
        Me.HPI3.Size = New System.Drawing.Size(131, 26)
        Me.HPI3.TabIndex = 5
        Me.HPI3.Text = "52500"
        '
        'HPI1
        '
        Me.HPI1.Location = New System.Drawing.Point(243, 23)
        Me.HPI1.Name = "HPI1"
        Me.HPI1.Size = New System.Drawing.Size(131, 26)
        Me.HPI1.TabIndex = 4
        Me.HPI1.Text = "49500"
        '
        'PI2
        '
        Me.PI2.AutoSize = True
        Me.PI2.Location = New System.Drawing.Point(21, 64)
        Me.PI2.Name = "PI2"
        Me.PI2.Size = New System.Drawing.Size(160, 24)
        Me.PI2.TabIndex = 3
        Me.PI2.Text = "Super Supreme"
        Me.PI2.UseVisualStyleBackColor = True
        '
        'PI3
        '
        Me.PI3.AutoSize = True
        Me.PI3.Location = New System.Drawing.Point(21, 94)
        Me.PI3.Name = "PI3"
        Me.PI3.Size = New System.Drawing.Size(118, 24)
        Me.PI3.TabIndex = 2
        Me.PI3.Text = "Tunal Melt"
        Me.PI3.UseVisualStyleBackColor = True
        '
        'PI4
        '
        Me.PI4.AutoSize = True
        Me.PI4.Location = New System.Drawing.Point(21, 130)
        Me.PI4.Name = "PI4"
        Me.PI4.Size = New System.Drawing.Size(190, 24)
        Me.PI4.TabIndex = 1
        Me.PI4.Text = "American Favourite"
        Me.PI4.UseVisualStyleBackColor = True
        '
        'PI1
        '
        Me.PI1.AutoSize = True
        Me.PI1.Location = New System.Drawing.Point(21, 25)
        Me.PI1.Name = "PI1"
        Me.PI1.Size = New System.Drawing.Size(124, 24)
        Me.PI1.TabIndex = 0
        Me.PI1.Text = "Meat Lover"
        Me.PI1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.HPA3)
        Me.GroupBox2.Controls.Add(Me.HPA2)
        Me.GroupBox2.Controls.Add(Me.HPA1)
        Me.GroupBox2.Controls.Add(Me.JPA3)
        Me.GroupBox2.Controls.Add(Me.PA3)
        Me.GroupBox2.Controls.Add(Me.JPA2)
        Me.GroupBox2.Controls.Add(Me.JPA1)
        Me.GroupBox2.Controls.Add(Me.PA1)
        Me.GroupBox2.Controls.Add(Me.PA2)
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox2.Location = New System.Drawing.Point(751, 193)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(476, 164)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "PIasta"
        '
        'HPA3
        '
        Me.HPA3.Location = New System.Drawing.Point(187, 115)
        Me.HPA3.Name = "HPA3"
        Me.HPA3.Size = New System.Drawing.Size(131, 26)
        Me.HPA3.TabIndex = 8
        Me.HPA3.Text = "41000"
        '
        'HPA2
        '
        Me.HPA2.Location = New System.Drawing.Point(187, 68)
        Me.HPA2.Name = "HPA2"
        Me.HPA2.Size = New System.Drawing.Size(131, 26)
        Me.HPA2.TabIndex = 9
        Me.HPA2.Text = "48000"
        '
        'HPA1
        '
        Me.HPA1.Location = New System.Drawing.Point(187, 23)
        Me.HPA1.Name = "HPA1"
        Me.HPA1.Size = New System.Drawing.Size(131, 26)
        Me.HPA1.TabIndex = 10
        Me.HPA1.Text = "43000"
        '
        'JPA3
        '
        Me.JPA3.Location = New System.Drawing.Point(364, 117)
        Me.JPA3.Name = "JPA3"
        Me.JPA3.Size = New System.Drawing.Size(71, 26)
        Me.JPA3.TabIndex = 16
        Me.JPA3.Text = "0"
        Me.JPA3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PA3
        '
        Me.PA3.AutoSize = True
        Me.PA3.Location = New System.Drawing.Point(6, 117)
        Me.PA3.Name = "PA3"
        Me.PA3.Size = New System.Drawing.Size(128, 24)
        Me.PA3.TabIndex = 8
        Me.PA3.Text = "Cremy Beef"
        Me.PA3.UseVisualStyleBackColor = True
        '
        'JPA2
        '
        Me.JPA2.Location = New System.Drawing.Point(364, 70)
        Me.JPA2.Name = "JPA2"
        Me.JPA2.Size = New System.Drawing.Size(71, 26)
        Me.JPA2.TabIndex = 11
        Me.JPA2.Text = "0"
        Me.JPA2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'JPA1
        '
        Me.JPA1.Location = New System.Drawing.Point(364, 25)
        Me.JPA1.Name = "JPA1"
        Me.JPA1.Size = New System.Drawing.Size(71, 26)
        Me.JPA1.TabIndex = 12
        Me.JPA1.Text = "0"
        Me.JPA1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PA1
        '
        Me.PA1.AutoSize = True
        Me.PA1.Location = New System.Drawing.Point(6, 25)
        Me.PA1.Name = "PA1"
        Me.PA1.Size = New System.Drawing.Size(156, 24)
        Me.PA1.TabIndex = 9
        Me.PA1.Text = "Beef Shpagetti"
        Me.PA1.UseVisualStyleBackColor = True
        '
        'PA2
        '
        Me.PA2.AutoSize = True
        Me.PA2.Location = New System.Drawing.Point(6, 70)
        Me.PA2.Name = "PA2"
        Me.PA2.Size = New System.Drawing.Size(147, 24)
        Me.PA2.TabIndex = 7
        Me.PA2.Text = "Beef Lasagna"
        Me.PA2.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.HM3)
        Me.GroupBox3.Controls.Add(Me.HM2)
        Me.GroupBox3.Controls.Add(Me.HM1)
        Me.GroupBox3.Controls.Add(Me.M3)
        Me.GroupBox3.Controls.Add(Me.JM3)
        Me.GroupBox3.Controls.Add(Me.JM2)
        Me.GroupBox3.Controls.Add(Me.JM1)
        Me.GroupBox3.Controls.Add(Me.M2)
        Me.GroupBox3.Controls.Add(Me.M1)
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox3.Location = New System.Drawing.Point(160, 379)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(476, 182)
        Me.GroupBox3.TabIndex = 11
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Minuman"
        '
        'HM3
        '
        Me.HM3.Location = New System.Drawing.Point(243, 127)
        Me.HM3.Name = "HM3"
        Me.HM3.Size = New System.Drawing.Size(131, 26)
        Me.HM3.TabIndex = 7
        Me.HM3.Text = "22000"
        '
        'HM2
        '
        Me.HM2.Location = New System.Drawing.Point(243, 82)
        Me.HM2.Name = "HM2"
        Me.HM2.Size = New System.Drawing.Size(131, 26)
        Me.HM2.TabIndex = 8
        Me.HM2.Text = "25000"
        '
        'HM1
        '
        Me.HM1.Location = New System.Drawing.Point(243, 35)
        Me.HM1.Name = "HM1"
        Me.HM1.Size = New System.Drawing.Size(131, 26)
        Me.HM1.TabIndex = 9
        Me.HM1.Text = "24000"
        '
        'M3
        '
        Me.M3.AutoSize = True
        Me.M3.Location = New System.Drawing.Point(21, 129)
        Me.M3.Name = "M3"
        Me.M3.Size = New System.Drawing.Size(176, 24)
        Me.M3.TabIndex = 4
        Me.M3.Text = "Green Tea Shake"
        Me.M3.UseVisualStyleBackColor = True
        '
        'JM3
        '
        Me.JM3.Location = New System.Drawing.Point(399, 127)
        Me.JM3.Name = "JM3"
        Me.JM3.Size = New System.Drawing.Size(71, 26)
        Me.JM3.TabIndex = 13
        Me.JM3.Text = "0"
        Me.JM3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'JM2
        '
        Me.JM2.Location = New System.Drawing.Point(399, 84)
        Me.JM2.Name = "JM2"
        Me.JM2.Size = New System.Drawing.Size(71, 26)
        Me.JM2.TabIndex = 14
        Me.JM2.Text = "0"
        Me.JM2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'JM1
        '
        Me.JM1.Location = New System.Drawing.Point(399, 35)
        Me.JM1.Name = "JM1"
        Me.JM1.Size = New System.Drawing.Size(71, 26)
        Me.JM1.TabIndex = 15
        Me.JM1.Text = "0"
        Me.JM1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'M2
        '
        Me.M2.AutoSize = True
        Me.M2.Location = New System.Drawing.Point(21, 84)
        Me.M2.Name = "M2"
        Me.M2.Size = New System.Drawing.Size(143, 24)
        Me.M2.TabIndex = 5
        Me.M2.Text = "Toffee coffee"
        Me.M2.UseVisualStyleBackColor = True
        '
        'M1
        '
        Me.M1.AutoSize = True
        Me.M1.Location = New System.Drawing.Point(21, 37)
        Me.M1.Name = "M1"
        Me.M1.Size = New System.Drawing.Size(125, 24)
        Me.M1.TabIndex = 6
        Me.M1.Text = "Choco Mint"
        Me.M1.UseVisualStyleBackColor = True
        '
        'BtnHitung
        '
        Me.BtnHitung.BackColor = System.Drawing.Color.DarkOrange
        Me.BtnHitung.ForeColor = System.Drawing.SystemColors.Control
        Me.BtnHitung.Location = New System.Drawing.Point(797, 379)
        Me.BtnHitung.Name = "BtnHitung"
        Me.BtnHitung.Size = New System.Drawing.Size(389, 52)
        Me.BtnHitung.TabIndex = 12
        Me.BtnHitung.Text = "HITUNG"
        Me.BtnHitung.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(675, 451)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 20)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "TOTAL"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(675, 541)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 20)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "KEMBALIAN"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.Control
        Me.Label5.Location = New System.Drawing.Point(675, 494)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 20)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "BAYAR"
        '
        'TextTotal
        '
        Me.TextTotal.Location = New System.Drawing.Point(797, 451)
        Me.TextTotal.Name = "TextTotal"
        Me.TextTotal.Size = New System.Drawing.Size(389, 26)
        Me.TextTotal.TabIndex = 16
        Me.TextTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextKembali
        '
        Me.TextKembali.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.TextKembali.ForeColor = System.Drawing.Color.Yellow
        Me.TextKembali.Location = New System.Drawing.Point(797, 535)
        Me.TextKembali.Name = "TextKembali"
        Me.TextKembali.Size = New System.Drawing.Size(389, 26)
        Me.TextKembali.TabIndex = 17
        Me.TextKembali.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBayar
        '
        Me.TextBayar.Location = New System.Drawing.Point(797, 491)
        Me.TextBayar.Name = "TextBayar"
        Me.TextBayar.Size = New System.Drawing.Size(389, 26)
        Me.TextBayar.TabIndex = 18
        Me.TextBayar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(738, 56)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(292, 20)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "NAZWA YUPADA PUTRI SITORUS"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(737, 96)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(148, 37)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "2522139"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOrange
        Me.ClientSize = New System.Drawing.Size(1303, 674)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TextBayar)
        Me.Controls.Add(Me.TextKembali)
        Me.Controls.Add(Me.TextTotal)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.BtnHitung)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents JPI2 As TextBox
    Friend WithEvents JPI3 As TextBox
    Friend WithEvents JPI4 As TextBox
    Friend WithEvents JPI1 As TextBox
    Friend WithEvents HPI2 As TextBox
    Friend WithEvents HPI4 As TextBox
    Friend WithEvents HPI3 As TextBox
    Friend WithEvents HPI1 As TextBox
    Friend WithEvents PI2 As CheckBox
    Friend WithEvents PI3 As CheckBox
    Friend WithEvents PI4 As CheckBox
    Friend WithEvents PI1 As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents HPA3 As TextBox
    Friend WithEvents HPA2 As TextBox
    Friend WithEvents HPA1 As TextBox
    Friend WithEvents JPA3 As TextBox
    Friend WithEvents PA3 As CheckBox
    Friend WithEvents JPA2 As TextBox
    Friend WithEvents JPA1 As TextBox
    Friend WithEvents PA1 As CheckBox
    Friend WithEvents PA2 As CheckBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents HM3 As TextBox
    Friend WithEvents HM2 As TextBox
    Friend WithEvents HM1 As TextBox
    Friend WithEvents M3 As CheckBox
    Friend WithEvents JM3 As TextBox
    Friend WithEvents JM2 As TextBox
    Friend WithEvents JM1 As TextBox
    Friend WithEvents M2 As CheckBox
    Friend WithEvents M1 As CheckBox
    Friend WithEvents BtnHitung As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TextTotal As TextBox
    Friend WithEvents TextKembali As TextBox
    Friend WithEvents TextBayar As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
End Class
